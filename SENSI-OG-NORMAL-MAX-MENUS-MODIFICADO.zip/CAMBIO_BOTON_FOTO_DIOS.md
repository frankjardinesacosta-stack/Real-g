# Cambio del botón Free Fire MAX
- Se sustituyó la imagen del banner por la foto de Dios enviada por el usuario.
- Se ajustó la foto a formato horizontal conservando la imagen completa en el centro y usando un fondo ampliado/desenfocado a los lados.
- Se añadió el texto visible “ABRIR FREE FIRE MAX”.
- Se conservó la acción de apertura existente `freefiremax://`; esto no garantiza que iOS pueda abrir el juego si el esquema no está registrado por la instalación.
